/*
Navicat MySQL Data Transfer

Source Server         : kaze
Source Server Version : 80017
Source Host           : localhost:3306
Source Database       : saler1.0

Target Server Type    : MYSQL
Target Server Version : 80017
File Encoding         : 65001

Date: 2019-12-14 10:49:56
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for order
-- ----------------------------
DROP TABLE IF EXISTS `order`;
CREATE TABLE `order` (
  `oNo` char(12) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `oMoney` double(10,3) DEFAULT NULL,
  `clientState` int(11) DEFAULT NULL,
  `ordertime` date DEFAULT NULL,
  `id` char(12) DEFAULT NULL,
  `gNo` char(12) DEFAULT NULL,
  `adminState` int(11) DEFAULT NULL,
  PRIMARY KEY (`oNo`),
  KEY `order_ibfk_1` (`id`),
  KEY `order_ibfk_2` (`gNo`),
  CONSTRAINT `order_ibfk_1` FOREIGN KEY (`id`) REFERENCES `user` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `order_ibfk_2` FOREIGN KEY (`gNo`) REFERENCES `product` (`gNo`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of order
-- ----------------------------
INSERT INTO `order` VALUES ('01', '100.000', '1', '2019-12-01', '123456', '01', '2');
INSERT INTO `order` VALUES ('02', '20.000', '1', '2019-12-01', '123456', '03', '1');
INSERT INTO `order` VALUES ('03', '71.000', '1', '2019-12-01', '123456', '05', '1');
INSERT INTO `order` VALUES ('04', '71.000', '1', '2019-12-01', 'gao1234', '05', '1');
INSERT INTO `order` VALUES ('08e4d6528226', '10.000', '1', '2019-12-08', 'gao1234', '02', '1');
INSERT INTO `order` VALUES ('09a1c6d8744b', '10.000', '1', '2019-12-08', 'gao1234', '02', '1');
INSERT INTO `order` VALUES ('0b8aab5b7715', '100.000', '1', '2019-12-08', 'gao1234', '01', '1');
INSERT INTO `order` VALUES ('1d128282b552', '10.000', '1', '2019-12-08', 'gao1234', '02', '1');
INSERT INTO `order` VALUES ('25d135337f33', '100.000', '1', '2019-12-03', 'gao1234', '01', '1');
INSERT INTO `order` VALUES ('26adebac0620', '10.000', '1', '2019-12-08', 'gao1234', '02', '1');
INSERT INTO `order` VALUES ('27536f95aba7', '10.000', '1', '2019-12-08', 'gao1234', '02', '1');
INSERT INTO `order` VALUES ('30e7f500c858', '10.000', '1', '2019-12-08', 'gao1234', '02', '1');
INSERT INTO `order` VALUES ('39c818b4d55c', '10.000', '1', '2019-12-03', 'gao1234', '02', '1');
INSERT INTO `order` VALUES ('61d776171826', '20.000', '1', '2019-12-03', 'gao1234', '03', '1');
INSERT INTO `order` VALUES ('7325a131f2c1', '10.000', '1', '2019-12-08', 'gao1234', '02', '1');
INSERT INTO `order` VALUES ('8d195bb343af', '10.000', '1', '2019-12-08', 'gao1234', '02', '1');
INSERT INTO `order` VALUES ('96eb9c3f38f9', '10.000', '1', '2019-12-08', 'gao1234', '02', '1');
INSERT INTO `order` VALUES ('d25a56f97d64', '100.000', '1', '2019-12-14', 'gao1234', '01', '1');
INSERT INTO `order` VALUES ('db717c5221ae', '100.000', '1', '2019-12-08', 'gao1234', '01', '1');
INSERT INTO `order` VALUES ('ddcf5d51b9b2', '10.000', '2', '2019-12-03', 'gao1234', '02', '1');
INSERT INTO `order` VALUES ('dec9219f8a97', '10.000', '1', '2019-12-08', 'gao1234', '02', '1');
INSERT INTO `order` VALUES ('f9410d3a26ca', '100.000', '2', '2019-12-03', 'gao1234', '01', '1');

-- ----------------------------
-- Table structure for product
-- ----------------------------
DROP TABLE IF EXISTS `product`;
CREATE TABLE `product` (
  `gNo` char(12) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `gName` char(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `gDescription` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `gPostTime` date DEFAULT NULL,
  `gPrice` double(10,2) NOT NULL,
  `gScore` double(3,1) DEFAULT NULL,
  `gType` varchar(255) DEFAULT NULL,
  `gImgurl` varchar(255) DEFAULT NULL,
  `gState` int(11) DEFAULT NULL,
  PRIMARY KEY (`gNo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of product
-- ----------------------------
INSERT INTO `product` VALUES ('01', '暗杀神', '', '2019-12-01', '100.00', '8.0', '卡牌', '/productImg/anshashen.png', '1');
INSERT INTO `product` VALUES ('02', '阴阳师', null, '2019-11-14', '10.00', '8.0', '卡牌', '/productImg/yys.jpg', '1');
INSERT INTO `product` VALUES ('03', '饥荒', '', '2019-11-13', '20.00', '8.6', '冒险', '/productImg/jihuang.jpg', '1');
INSERT INTO `product` VALUES ('04', '植物大战僵尸', null, '2019-12-01', '30.50', '10.0', '塔防', '/productImg/plant.jpg', '1');
INSERT INTO `product` VALUES ('05', '女神异闻录', null, '2019-12-01', '71.00', '9.5', 'RPG', '/productImg/nvshen.jpg', '1');
INSERT INTO `product` VALUES ('c009566120ef', '游戏王', '', '2019-12-04', '50.00', '7.8', '卡牌', '/productImg/youxiwang.jpg', '2');
INSERT INTO `product` VALUES ('ce8b2b5c4020', '旅法师对决', '', '2019-12-07', '65.00', '7.2', '策略', '/productImg/0/13/26692fec-aa0f-4322-9a3c-eaf071654d26.jpg', '1');

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` char(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `name` char(30) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `password` char(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `money` double(10,3) DEFAULT NULL,
  `email` char(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `role` char(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('1212', 'AD', '12345', '0.000', '2950802077@qq.com', '普通用户');
INSERT INTO `user` VALUES ('12333', 'aa', '12345', '10000.000', '2950802077@qq.com', '普通用户');
INSERT INTO `user` VALUES ('123456', 'AIAI', '12345', '0.000', '2950802077@qq.com', null);
INSERT INTO `user` VALUES ('dong45', '阿冬', '12345', '0.000', '2950802077@qq.com', '普通用户');
INSERT INTO `user` VALUES ('gao123', 'JIANFENG GAO', '12345', '0.000', '2950802077@qq.com', '超级用户');
INSERT INTO `user` VALUES ('gao1234', 'JIANFENG GAO', '12345', '600.000', '2950802077@qq.com', null);

-- ----------------------------
-- Procedure structure for addOrderList
-- ----------------------------
DROP PROCEDURE IF EXISTS `addOrderList`;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `addOrderList`(IN onum char(12),IN cost double,IN uid char(12),IN gnum char(12))
BEGIN
	#Routine body goes here...
insert into `order`(oNo,oMoney,clientState,adminState,ordertime,id,gNo) 
values(onum,cost,1,1,CURDATE(),uid,gnum);

update `user`
SET money=money-cost
WHERE id=uid;

END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for insertNewUser
-- ----------------------------
DROP PROCEDURE IF EXISTS `insertNewUser`;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `insertNewUser`(IN id char(20),IN un char(30),IN pw char(20),IN mail char(255))
BEGIN
	#Routine body goes here...
INSERT INTO `user`(id,name,password,money,email,role)
VALUES(id,un,pw,10000.0,mail,"普通用户");

END
;;
DELIMITER ;
