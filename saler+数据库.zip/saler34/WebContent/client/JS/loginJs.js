/**
 * 
 */

function turnToRegister() {
	window.location.href="../client/register.jsp";
}